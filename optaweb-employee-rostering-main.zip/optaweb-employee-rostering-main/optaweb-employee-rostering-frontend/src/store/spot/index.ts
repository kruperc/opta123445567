
import * as spotOperations from './operations';
import * as spotSelectors from './selectors';
import reducer from './reducers';

export {
  spotOperations,
  spotSelectors,
};

export default reducer;
