
import RestServiceClient from './RestServiceClient';

export default RestServiceClient;
