
import * as skillOperations from './operations';
import * as skillSelectors from './selectors';
import reducer from './reducers';

export {
  skillOperations,
  skillSelectors,
};

export default reducer;
