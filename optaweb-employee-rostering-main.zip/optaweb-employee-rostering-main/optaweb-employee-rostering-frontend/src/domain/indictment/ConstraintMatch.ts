import { HardMediumSoftScore } from '../HardMediumSoftScore';

export interface ConstraintMatch {
  score: HardMediumSoftScore;
}
