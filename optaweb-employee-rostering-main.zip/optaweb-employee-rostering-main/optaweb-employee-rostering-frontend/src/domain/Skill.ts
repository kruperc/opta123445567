
import { DomainObject } from './DomainObject';

export interface Skill extends DomainObject {
  name: string;
}
