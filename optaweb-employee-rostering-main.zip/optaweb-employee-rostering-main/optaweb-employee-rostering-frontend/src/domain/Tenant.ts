
export interface Tenant {
  name: string;
  id?: number;
  version?: number;
}
