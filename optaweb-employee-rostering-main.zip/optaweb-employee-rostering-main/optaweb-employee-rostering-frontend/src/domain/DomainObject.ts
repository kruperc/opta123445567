
export interface DomainObject {
  tenantId: number;
  id?: number;
  version?: number;
}
