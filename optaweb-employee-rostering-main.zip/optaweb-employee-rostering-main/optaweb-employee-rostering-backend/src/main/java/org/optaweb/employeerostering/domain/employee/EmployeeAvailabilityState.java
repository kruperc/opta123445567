package org.optaweb.employeerostering.domain.employee;

public enum EmployeeAvailabilityState {
    UNAVAILABLE,
    UNDESIRED,
    DESIRED
}
